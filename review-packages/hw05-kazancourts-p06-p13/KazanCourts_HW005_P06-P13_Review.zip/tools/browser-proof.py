import json
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path('/workspace/hw05-full-review')
spans=json.loads((root/'private-b/raw/full-trace.json').read_text())
trace=spans[0]['trace_id']
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1440,'height':1000})
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:19006/',wait_until='domcontentloaded')
 page.locator('#metrics tr').first.wait_for()
 page.fill('#trace',trace);page.click('#show')
 page.wait_for_function("document.querySelector('#spans').textContent.includes('notification.persist')")
 text=page.locator('#spans').inner_text()
 for event in ['http.request','weather.transition','kafka.publish','kafka.consume','notification.persist']:assert event in text
 assert not errors,errors
 page.screenshot(path=str(root/'dashboard.png'),full_page=True)
 (root/'browser-proof.json').write_text(json.dumps({'result':'PASS','trace_id':trace,'rows':page.locator('#metrics tr').count(),'javascript_errors':errors},indent=2))
 browser.close()
print('PASS real browser dashboard: dynamic metrics and full trace rendered')
