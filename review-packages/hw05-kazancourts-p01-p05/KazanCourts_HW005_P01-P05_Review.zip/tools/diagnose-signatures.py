import subprocess,tarfile,tempfile,re
patterns=[rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'AKIA[0-9A-Z]{16}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
with tempfile.TemporaryFile() as f:
 subprocess.run(['docker','save','kc-hw05-review-db'],stdout=f,check=True);f.seek(0)
 with tarfile.open(fileobj=f,mode='r|*') as outer:
  for m in outer:
   if not m.isfile() or m.size<512: continue
   raw=outer.extractfile(m).read()
   if not any(re.search(p,raw) for p in patterns):continue
   try:
    import io
    with tarfile.open(fileobj=io.BytesIO(raw)) as layer:
     for member in layer:
      if not member.isfile(): continue
      b=layer.extractfile(member).read()
      for i,p in enumerate(patterns):
       match=re.search(p,b)
       if match:
        complete=bool(re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\s+[A-Za-z0-9+/=\r\n]{64,}-----END',b))
        print('bounded token', bool(re.search(rb'(?<![A-Za-z0-9])AKIA[0-9A-Z]{16}(?![A-Za-z0-9])',b)) if i==1 else 'n/a'); print('signature category',i,'file',member.name,'size',member.size,'complete PEM structure',complete)
   except tarfile.ReadError:
    print('non-layer metadata signature',m.name)
